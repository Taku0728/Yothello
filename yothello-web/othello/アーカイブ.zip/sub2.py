import subprocess

def aa(event, context):
    cmu = ["./yothello", "000000100800000000000008100000000100"]
    string = subprocess.run(cmu, stdout=subprocess.PIPE)
    stdout = string.stdout.decode("utf-8")
    return stdout
