import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
from scipy import spatial
import seaborn as sns
from scipy import io
from sklearn.model_selection import train_test_split

def makecov(x, x2, beta, sigma_f2):
    dist = spatial.distance.cdist(x, x2)
    K = sigma_f2 * np.exp(-beta*(dist*dist))
    return K


def GP_cve(train_X, train_y, test_X, beta, sigma_n2, sigma_f2):
    n = train_X.shape[0]
    # カーネルの計算
    K_tr_tr = makecov(train_X, train_X, beta, sigma_f2) + sigma_n2*np.eye(n)
    K_tr_tr_inv = np.linalg.inv(K_tr_tr)
    K_tr_ts = makecov(train_X, test_X, beta, sigma_f2)
    K_ts_tr = K_tr_ts.T
    K_ts_ts = makecov(test_X, test_X, beta, sigma_f2)

    # 予測値を計算
    f_star_mean = np.matmul(np.matmul(K_ts_tr, K_tr_tr_inv), train_y)
    f_star_cov = K_ts_ts - np.matmul(np.matmul(K_ts_tr, K_tr_tr_inv), K_tr_ts)
    f_star_std = np.sqrt(np.absolute(np.diag(f_star_cov)))
    return f_star_mean, f_star_cov, f_star_std


def RMSE(valid_y, f_star_mean):
    """
    test_y, f_star_mean：shape=(n_sample, 1)
    test_yとf_star_meanのRMSE(スカラー)を計算
    """
    dist2 = valid_y - f_star_mean
    rmse = np.sqrt(np.mean(dist2**2))
    return rmse


def CVE(X, y, beta, sigma_n2, sigma_f2, k):
    """
    ある(beta, sigma_n^2)の組みが与えられた時のCVEを計算する．
    データ(X, y)の順番に意味があると推定結果が偏る可能性があるので(X, y)をシャッフルする．
    for i in range(k):
       validデータの位置を変えながら(X, y)→(train_X, train_y, valid_X, valid_y)に分割．
       train_X, train_y, valid_Xからpred_yを予測．
       RMSE(valid_y, pred_y)でRMSEを計算しk回分ストアしておく．
    k個のRMSEの平均(スカラー)を返す．
    """

    n_train = 1004 # 訓練データの数
    n_valid = n_train // k # バリデーション用データ数
    np.random.seed(0) # シードの設定
    idx = list(np.random.permutation(np.arange(n_train))) # インデックスをランダムに並べ替え
    idx_set = set(idx)

    #rmseを保存する変数を定義
    rmse_keep = 0

    for i in range(k):

        # 訓練データとバリデーションデータに分割する、iごとにバリデーションデータの位置を変更
        idx_valid = idx[n_valid * i: n_valid * (i + 1)]
        idx_train = list(idx_set - set(idx_valid))
        train_X, train_y = X[idx_train], y[idx_train]
        valid_X, valid_y = X[idx_valid], y[idx_valid]
        valid_X_g1, valid_X_g2 = np.meshgrid(valid_X[:, 0], valid_X[:, 1])

        # 予測平均を求める
        f_star_mean, f_star_cov, f_star_std \
            = GP(train_X, train_y, valid_X, beta, sigma_n2, sigma_f2)

        # RMSEの計算
        rmse = RMSE(valid_y, f_star_mean)

        # RMSEを足し合わせる
        rmse_keep += rmse

    #RMSEを平均する
    cve = rmse_keep/k
    print(cve)
    return cve


def GS(X, y, k, step, sigman2_list, beta_list, sigma_f2_list):
    """
    beta_listとsigman2_listを設定．
    gridcve = np.array([[CVE(b, s) for s in sigman2_list] for b in beta_list])
    で(beta, sigma_n^2)の全組みにおけるcveを計算．
    cveが最小になる組みを見つけて返す．
    """

    # グリッドサーチする
    gridcve = np.array([[[CVE(X, y, b, s, s2, k) for s in sigman2_list] for b in beta_list])
    print(np.min(gridcve))

    # 最小地点のbetaとsigmaを出す
    min_idx = np.unravel_index(np.argmin(gridcve), gridcve.shape)
    best_beta = beta_list[min_idx[1]]
    best_sigma = sigman2_list[min_idx[2]]
    # GS_areaでハイパーパラメータの最適な範囲を絞るための値
    midle_beta = min_idx[1]//5
    midle_sigma = min_idx[2]//5

    # matplotに使う値
    beta_grid, sigma_grid = np.meshgrid(beta_list, sigman2_list)

    return gridcve, best_beta, best_sigma, beta_grid, sigma_grid, midle_beta, midle_sigma


def GS_area(data_X, data_y, k, step):
    sigman2_list = np.logspace(0 ,5, 51)
    sigma_f2_list = np.logspace(0 ,5, 51)
    beta_list = np.logspace(0 ,5, 51)

    gridcve,best_beta,best_sigma,best_sigma_f2,beta_grid,sigma_grid,midle_beta,midle_sigma,midle_sigma_f2 = GS(data_X, data_y, k, step, sigman2_list, beta_list, sigma_f2_list)

    sigman2_list = np.logspace(-15+(midle_sigma-1) ,-15+(midle_sigma-1)+2, 51)
    beta_list = np.logspace(-15+(midle_beta-1) ,-15+(midle_beta-1)+2, 51)
    sigma_f2_list = np.logspace(-15+(midle_sigma_f2-1) ,-15+(midle_sigma_f2-1)+2, 51)

    gridcve,best_beta,best_sigma,best_sigma_f2, beta_grid,sigma_grid,midle_beta,midle_sigma,midle_sigma_f2 = GS(data_X, data_y, k, step, sigman2_list, beta_list, sigma_f2_list)

    return gridcve,best_beta,best_sigma,best_sigma_f2,beta_grid,sigma_grid

data = io.loadmat('tsunami_data/donet_scenario.mat')
s = data['s']
d = data['d']
def split_train_test(num_data, num_train, seed):
   # return index of train and test data
    np.random.seed(seed)
    a = np.random.permutation(np.arange(num_data))
    index_train = a[:num_train]
    index_test = a[num_train:]
    return index_train, index_test

# split data
num_train = 1004
index_train, index_test = split_train_test(len(d), num_train, 622)
train_s = s[index_train]
train_d = d[index_train]
test_s = s[index_test]
test_d = d[index_test]

np.random.seed(0) # シードの設定
idx = list(np.random.permutation(np.arange(1004))) # インデックスをランダムに並べ替え
#idx_set = list(set(idx))

train_s = train_s[idx]
train_d = train_d[idx]

step = 101
beta_list = np.logspace(-10 ,0, step)
sigman2_list = np.logspace(-7, 3, step)

gridcve, best_beta, best_sigma, beta_grid, sigma_grid, midle_beta, midle_sigma = GS(train_s, train_d, k, step, sigman2_list, beta_list)

np.save("out/gridfe.npy", gridcve)
