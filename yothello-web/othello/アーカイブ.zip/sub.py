import subprocess

def aa(event, context):
    cmu = ["./hello"]
    string = subprocess.run(cmu, stdout=subprocess.PIPE)
    stdout = string.stdout.decode("utf-8")
    return stdout
