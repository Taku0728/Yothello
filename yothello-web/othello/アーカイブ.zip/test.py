import json
import sub

def aa(event, context):
    if 'code' not in event['queryStringParameters']:
        return {
            'statusCode': 400,
            'body': json.dumps('Error')
        }
    else:
        code = event['queryStringParameters']['code']
        stdout = sub.aa(event, context)
        # cmu = [""]
        # string = subprocess.run(cmu, stdout=subprocess.PIPE)
        # stdout = string.stdout.decode("utf-8")
        #print(stdout)
        return {
            'statusCode': 200,
            'body': json.dumps(stdout)
        }
